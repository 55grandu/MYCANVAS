VLEX is released under the terms of the [MIT license](http://en.wikipedia.org/wiki/MIT_License).

The MIT License is simple and easy to understand and it places almost no restrictions on what you can do with VLEX.

You are free to use VLEX in any other project (even commercial projects) as long as the copyright header is left intact.